#!/usr/bin/env bash
# One command, in a codespace terminal, for the night's whole run: ask FR24, build, publish, push.
#
#     cd /workspaces/FR24 && ./tools/nightly.sh
#
# Why it lives here and not only in Actions: run #10 (3 Nov, scheduled) fetched from a GitHub runner
# and got nothing back at all — `Flightradar24 answered nothing from this runner`. The build and the
# commit work fine from Actions; the *asking* is what the runner cannot always do. This script does
# the same steps from a machine you choose, and pushes, which is what the rest of the pipeline is
# already built to react to.
#
#   --no-pull   work on the checkout as it is (default pulls first)
#   --no-push   build and commit locally, push nothing — use this to see what it would do
#   --dry-run   print the plan and the reachability probe, touch nothing
#   --force     go on even when FR24 refuses this network (the build then has no capture to use)
#   --hours N   how far back to ask FR24 for (default 96 = 4 days, its trail horizon)
#   --backfill N  after tonight's fetch, ask again for the last N days from FR24's recordings of
#                 each flight (default 7, 0 turns it off). This is what makes a night this machine
#                 could not reach repairable instead of lost.
#   --trail S     live (the map's trail), playback (FR24's recording), both (default: live, and
#                 playback for anything the trail gave too little of)
#   --skip-fetch / --skip-weather
#   --from-capture F   build from a capture archive somebody else fetched: F is unpacked into
#                      work/ci_capture and the fetch step is skipped. Explicit only — the nightly
#                      never goes looking for one, and FR data.zip is never a source. This is the
#                      way a capture gets in when the fetching machine is not the pushing machine.
#
# Exit codes: 0 pushed or nothing to push, 2 the machine could not reach FR24 at all (see PROBE
# below), 3 built and committed but the push failed, 4 nothing new anywhere and nothing was written.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2

pull=1 push=1 dry=0 dofetch=1 doweather=1 hours=96 force=0 backfill=7 trail=both from_cap=
while [ $# -gt 0 ]; do
  case "$1" in
    --no-pull) pull=0 ;;
    --no-push) push=0 ;;
    --dry-run) dry=1 ;;
    --force) force=1 ;;
    --skip-fetch) dofetch=0 ;;
    --skip-weather) doweather=0 ;;
    --hours) shift; hours="${1:-96}" ;;
    --backfill) shift; backfill="${1:-7}" ;;
    --trail) shift; trail="${1:-both}" ;;
    --from-capture) shift; from_cap="${1:-}" ;;
    *) echo "unknown flag: $1"; exit 2 ;;
  esac
  shift
done

# The publish dir is the checkout root in CI; here it is the same, and saying so in the environment
# means no `fr24_publish` symlink has to exist for the scripts to find their own data.
export FR24_PUBLISH="$PWD"
# Several scripts in work/ reach their data as `fr24_publish/<file>`; Actions makes that name with a
# symlink and the codespace has no such link, which is what died last run (ingest: FileNotFoundError on
# /workspaces/FR24/fr24_publish/FR data.zip, and work/weather.py reporting "no airport table"). It is
# in .gitignore, so the link itself is never committed.
if [ ! -e fr24_publish ]; then ln -s "$PWD" fr24_publish && say "  linked fr24_publish -> $PWD"; fi
say() { printf '%s\n' "$*"; }
stamp=$(date -u +%Y-%m-%dT%H:%MZ)

say "== FR24 reachability from this machine"
probe=$(curl -s -m 25 -o /dev/null -w '%{http_code}' \
  -A 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36' \
  'https://api.flightradar24.com/common/v1/flight/list.json?query=UR110&fetchBy=flight&mode=original&limit=1')
case "$probe" in
  200) say "  HTTP $probe — this machine can ask FR24 directly." ;;
  429) say "  HTTP 429 — reachable but throttled: raise --sleep, or run it again in a few minutes." ;;
  000) say "  no answer at all — no route, DNS or TLS. Nothing here will fetch until that changes." ;;
  *)   say "  HTTP $probe — FR24 refused this network the way it refused the runner." ;;
esac
if [ -n "${fr24_subscription_key:-}${FR24_SUBSCRIPTION_KEY:-}${fr24_username:-}${FR24_USERNAME:-}" ] \
   || [ -f "$HOME/.config/fr24/fr24.conf" ]; then
  say "  a FR24 subscription key is visible to this script: the deeper history paging will be used."
else
  say "  no FR24 credentials here, so history paging stays at about a week per flight number."
fi
if [ "$probe" != 200 ] && [ "$probe" != 429 ] && [ "$force" != 1 ] && [ "$dofetch" = 1 ]; then
  say ""
  say "FR24 refused this network (HTTP $probe), so there is nothing to fetch and this run stops here."
  say "  It is not a code problem: api.flightradar24.com answers 200 from some networks and 403 from"
  say "  Microsoft's - which is what GitHub Actions runners AND codespaces are. Run this script from a"
  say "  machine on a network that answers (your own computer, on a cron), or say so and I will build a"
  say "  second source in. --force runs the build on what the branch already holds, and commits nothing"
  say "  it has not been given."
  exit 2
fi
if [ "$dry" = 1 ]; then
  say "-- dry run: would pull, fetch ${hours}h + repair ${backfill}d into work/ci_capture, build, publish flight_paths/,"
  say "  snapshot the weather, then $([ "$push" = 1 ] && echo 'commit and push' || echo 'commit only')."
  [ "$probe" = 200 ] || exit 2
  exit 0
fi

# A capture handed over from outside: unpacked into place, and the fetch is off, because the
# fetching is what has already been done. Named explicitly, and nothing here will fall back to the
# archive on the branch if the file turns out to hold no flights.
if [ -n "$from_cap" ]; then
  [ -f "$from_cap" ] || { say "--from-capture: no such file ($from_cap)"; exit 2; }
  command -v unzip >/dev/null || { say "--from-capture: this machine has no unzip"; exit 2; }
  mkdir -p work/ci_capture
  unzip -o -q "$from_cap" -d work/ci_capture || { say "--from-capture: could not unpack $from_cap"; exit 2; }
  say "== capture handed in: $from_cap"
  say "   $(ls work/ci_capture/*.csv 2>/dev/null | wc -l) flight file(s), zip $(wc -c < work/ci_capture/"FR data.zip" 2>/dev/null || echo 0) B; fetch step skipped"
  dofetch=0
fi

[ "$pull" = 1 ] && { say "== pull"; git pull --ff-only || say "  (not a fast-forward; carrying on with what is here)"; }

say "== fetch, last ${hours}h of trails"
mkdir -p work/ci_capture
frc=0
if [ "$dofetch" = 1 ]; then
  if [ "$probe" = 200 ] || [ "$probe" = 429 ]; then
    python3 tools/fetch_fr24.py --source board --trail "$trail" --out work/ci_capture --sleep 3 || frc=$?
    say "  fetch exit $frc (0 captured, 3 nothing in the window, 5 refused to name a flight, 4 no answer)"
  else
    frc=4
    say "  skipped the fetch: the probe above says this network gets nothing back (exit 4)"
  fi
else
  say "  --skip-fetch"
fi

# The repair pass. FR24 keeps the map's live trail only about four days, so a night this machine
# could not reach used to be gone for good. Its recording behind each flight id stays available for
# weeks, so the last --backfill days are asked for a second time by flight number and anything
# missed arrives beside tonight's capture, in the same seven columns. The numbers to ask about come
# from our own month logs; the flights themselves come from FR24, which is what the rule about not
# building on a person's upload is actually about.
if [ "$dofetch" = 1 ] && [ "$backfill" -gt 0 ] && { [ "$probe" = 200 ] || [ "$probe" = 429 ]; }; then
  say "== repair pass: last ${backfill} days, from FR24's recordings (trail=$trail)"
  b_since=$(date -u -d "-${backfill} days" +%Y-%m-%d 2>/dev/null || date -u -v-${backfill}d +%Y-%m-%d)
  brc=0
  python3 tools/fetch_fr24.py --source log --since "$b_since" --until "$(date -u +%Y-%m-%d)" \
      --trail playback --out work/ci_capture --sleep 1.5 || brc=$?
  say "  repair exit $brc"
fi

# Keep the raw pull where it is committed. work/ci_capture is gitignored and a codespace stops after
# half an hour of idleness: a capture that only ever lived there is a capture that can vanish.
cap=""
if [ -f work/ci_capture/"FR data.zip" ]; then
  keep="capture/$stamp"
  mkdir -p "$keep"
  cp work/ci_capture/*.csv work/ci_capture/capture_manifest.json "$keep"/ 2>/dev/null
  cp work/ci_capture/"FR data.zip" "$keep"/"capture.zip"
  cap="--capture-zip $keep/capture.zip"
  say "  raw pull kept at $keep ($(ls "$keep" | wc -l) files)"
fi

say "== build"
build_rc=0
if [ -n "$cap" ]; then
  python3 tools/ci_run.py $cap --changed-file /tmp/nightly_changed.txt || build_rc=$?
fi

say "== weather snapshot (aviationweather.gov keeps ~8 days, and SIGMETs only until they expire)"
if [ "$doweather" = 1 ]; then
  python3 tools/fetch_awx.py --hours "$hours" --out work/awx --commit-dir reference/weather ||
    say "  ! aviationweather did not answer; the run carries on without weather"
fi

if [ "$build_rc" != 0 ]; then
  say "  build exit $build_rc: the ingest or a hard step failed, so nothing is committed and nothing is"
  say "  pushed - a half-built month on the branch is worse than a night without one. The log above says"
  say "  which step, and work/ci_capture/ still holds the raw pull if one was made."
  exit 1
fi

say "== what moved"
if ! git rev-parse --git-dir >/dev/null 2>&1; then
  say "  this is not a git checkout, so there is nothing to commit or push - the files above are the output"
  [ "$frc" = 4 ] && exit 2
  exit 0
fi
git add -A
st=$(git status --porcelain | wc -l | tr -d ' ')
git status --short | head -25
if [ "$st" = 0 ]; then
  say "  nothing to commit: the archive, the tables and the paths already hold everything this run found"
  [ "$frc" = 4 ] && exit 2
  exit 4
fi
head_before=$(git rev-parse HEAD 2>/dev/null || echo none)
git commit -q -m "Nightly $stamp — fr24-ci (from codespace): ${st} file(s), fetch exit $frc" ; crc=$?
head_now=$(git rev-parse HEAD 2>/dev/null || echo none)
if [ "$crc" != 0 ] || [ "$head_now" = "$head_before" ]; then
  # Say this plainly: a commit that did not happen must not be reported as a local commit that is
  # merely unpushed. On a fresh machine the usual reason is that git has no identity configured.
  say "  ! the commit did not happen (git exit $crc) - nothing was published, and no push was tried"
  say "    if this machine has no git identity: git config user.email you@example.com; git config user.name You"
  exit 3
fi
if [ "$push" = 1 ]; then
  say "== push"
  if git push; then
    say "  pushed. Actions will run off this push: it re-checks the freeze and the notifier, and it"
    say "  will not rebuild the tables, because there is no capture in the runner to build from."
    exit 0
  fi
  say "  ! push failed — the commit is safe locally; run 'git push' when the network is back"
  exit 3
fi
say "  --no-push: commit $(git rev-parse --short HEAD) is local only. 'git push' to publish it."
exit 0
