#!/usr/bin/env python3
r"""Fetch Uganda Airlines track history from Flightradar24 and write it in the shape this
repository already uses: one CSV per flight, `<FLIGHT>-<id>.csv`, seven columns.

    python3 tools/fetch_fr24.py --since 2026-10-26 --out work/ci_capture
    python3 tools/fetch_fr24.py --flights UR209,UR111 --dry-run
    python3 fr24_update.py --zip work/ci_capture/FR\ data.zip --month 2026-10   # then the usual chain

Two endpoints, both the ones flightradar24.com's own map page uses, and both answer from a
datacenter IP with no key:

  list   `api.flightradar24.com/common/v1/flight/list.json?query=<n>&fetchBy=flight&mode=original`
  trail  `data-live.flightradar24.com/clickhandler/?version=1.5&flight=<id>`

**The one fact that shapes this whole tool: `trail` is not history.** It is the live map's
buffer, and it survives about three to five days after landing. Measured on 30/31 Oct 2026:
`UR209` on 27 Oct returned its full 260-point trail, `UR209` on 24 Oct returned the flight
record with an empty trail. So a *frequent* run loses nothing, while a run after a fortnight
silently fetches nothing. That is why the nightly workflow exists, why `--since` defaults to
short, and why `empty` is reported as loudly as `captured`: an empty result here means "too
late", not "did not fly". Full history behind the account's own download is not reimplemented
here on purpose.

Politeness is not a nicety on these endpoints: one request per flight number, one per new
flight, `--sleep` between them, backoff on 429/5xx. A fleet of ~30 flight numbers costs about
40 requests, which is what a human clicking the page would spend.
"""
import argparse
import csv
import datetime as dt
import io
import glob
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

API = 'https://api.flightradar24.com/common/v1'
LIVE = 'https://data-live.flightradar24.com'
UA = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/120.0.0.0 Safari/537.36')
HEADER = ['Timestamp', 'UTC', 'Callsign', 'Position', 'Altitude', 'Speed', 'Direction']
EXTRA = ['VerticalSpeed', 'Squawk']            # only with --extra-columns; our readers expect the seven above


# Counted per HTTP call to FR24, not per flight number, because the difference matters: an empty
# answer and no answer at all look the same from here, and they mean "quiet night" and "blocked".
STATS = {'answered': 0, 'failed': 0, 'rows': 0}


# FR24 answers some questions only for a subscriber. Nothing here stores a secret: the key is
# read from the environment or ~/.config/fr24/fr24.conf, held in this process, and never written
# into a capture, a log line or the repository - the capture is committed and the log is shown to
# whoever opens the run.
AUTH = {}
CFG = os.path.expanduser('~/.config/fr24/fr24.conf')


def load_auth(log=None, want=True):
    """Exchange credentials for FR24's subscription key, the way the fr24 library does.

    Environment first (fr24_subscription_key / fr24_token, or fr24_username / fr24_password),
    then the config file, which uses the same [global] section the fr24 package reads:

        [global]
        username=you@example.com
        password=...

    With a key the flight listing answers 100 rows a page and lets us page backwards through
    history, so a night we missed can be repaired days later. Without one we still get about a
    week of listings and any single track whose flight id we already hold.
    """
    global AUTH
    if not want:
        return False
    env = lambda *names: next((os.environ[n] for n in names if os.environ.get(n)), None)
    u = env('fr24_username', 'FR24_USERNAME')
    p = env('fr24_password', 'FR24_PASSWORD')
    k = env('fr24_subscription_key', 'FR24_SUBSCRIPTION_KEY')
    if os.path.exists(CFG):
        try:
            import configparser
            c = configparser.ConfigParser()
            c.read(CFG)
            g = lambda o: c.get('global', o, fallback=None) or None
            u, p, k = g('username') or u, g('password') or p, g('subscription_key') or k
        except Exception as e:                                    # noqa: BLE001
            if log:
                log('  auth: could not read %s (%s) - continuing anonymously' % (CFG, type(e).__name__))
    if k:
        AUTH = {'token': k}
        if log:
            log('  auth: subscription key from configuration; history paging unlocked')
        return True
    if u and p:
        data = urllib.parse.urlencode({'email': u, 'password': p}).encode()
        req = urllib.request.Request(
            'https://www.flightradar24.com/user/login', data=data,
            headers={'User-Agent': UA, 'Accept': 'application/json',
                     'Origin': 'https://www.flightradar24.com', 'Referer': 'https://www.flightradar24.com/'})
        key, why = None, ''
        try:
            j = json.loads(urllib.request.urlopen(req, timeout=45).read())
            key = (j.get('userData') or {}).get('subscriptionKey')
            if not key:
                why = str(j.get('msg') or j.get('message') or 'no subscriptionKey in the answer')[:90]
        except Exception as e:                                    # noqa: BLE001
            why = '%s %s' % (type(e).__name__, getattr(e, 'code', '') or e)
        if key:
            AUTH = {'token': key}
            if log:
                log('  auth: logged in; key held in memory only, not written anywhere')
            return True
        if log:
            log('  auth: login did not return a key (%s) - continuing anonymously' % (why or 'unknown'))
    return False


def get(url, tries=4, log=None):
    """GET with backoff. 429 and 5xx are retried; a 4xx that is not 429 is a real answer."""
    delay = 2.0
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA,
                                                        'Accept': 'application/json',
                                                        'Accept-Language': 'en-GB,en;q=0.9'})
            with urllib.request.urlopen(req, timeout=40) as r:
                STATS['answered'] += 1
                return json.loads(r.read().decode('utf-8', 'replace'))
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and i < tries - 1:
                time.sleep(delay)
                delay *= 2.5
                continue
            STATS['failed'] += 1
            if log:
                log(f'    ! {e.code} {url[:110]}')
            return None
        except Exception as e:                                    # noqa: BLE001
            if i < tries - 1:
                time.sleep(delay)
                delay *= 2
                continue
            STATS['failed'] += 1
            if log:
                log(f'    ! {type(e).__name__} {e} {url[:90]}')
            return None
    return None


def known_ids(archive):
    """The flight ids already in the archive, read out of the filenames.

    `UR110-420b1d5b.csv` carries its id in the suffix and `3e02c7e0.csv` is the id alone, so
    the last stem of every name is the id — which is what makes a resume cheap and exact.
    """
    out = set()
    if not archive or not os.path.exists(archive):
        return out
    with zipfile.ZipFile(archive) as z:
        for n in z.namelist():
            if not n.lower().endswith('.csv'):
                continue
            stem = os.path.splitext(os.path.basename(n))[0]
            out.add(stem.split('-')[-1].lower())
    return out


def flights_from_board(day, log):
    """The flight numbers on the operator's own utilization board for `day` (YYYY-MM-DD).

    `fta.ugandairlines.com` is public and needs no sign-in, and its day board is the list of what UR
    actually intends to fly, so this is the source of truth for a night's fetch instead of anything a
    person last uploaded. `work/fta_pull.py` already knows how to download and read a board, so it is
    borrowed rather than reimplemented. An empty list means "the board did not answer"; the caller
    falls back to the per-number FR24 listings and says so.
    """
    try:
        sys.path.insert(0, os.path.join(ROOT, 'work'))
        import fta_pull
    except Exception as e:                                       # noqa: BLE001
        log(f'  board: cannot use work/fta_pull.py ({e}), using FR24 listings instead')
        return []
    d = dt.date.fromisoformat(day)
    # the index labels a board "Tuesday, 3rd Nov, 2026", so match the day with its ordinal suffix
    pat = re.compile(r'\b%d(?:st|nd|rd|th)\s+%s\b[^\d]*\b%d\b' % (d.day, d.strftime('%b'), d.year))
    uuid = ''
    for page in range(1, 4):
        html = fta_pull.fetch('/utilization-plans' + ('' if page == 1 else '?page=%d' % page))
        if not html:
            log('  board: the index page did not answer, using FR24 listings instead')
            return []
        for row in re.findall(r'<tr[^>]*>.*?</tr>', html, re.S):
            if pat.search(re.sub('<[^>]+>', ' ', row)):
                hit = re.findall(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', row)
                if hit:
                    uuid = hit[0]
                break
        if uuid:
            break
    if not uuid:
        log(f'  board: no day board for {day} in the first index pages, using FR24 listings instead')
        return []
    log(f'  board {day}: {uuid}')
    blob = fta_pull.fetch('/%s/excel' % uuid, binary=True)
    if not blob:
        log(f'  board: {uuid} did not download, using FR24 listings instead')
        return []
    try:
        sheet, rows = fta_pull.parse_excel(blob)
    except Exception as e:                                       # noqa: BLE001
        log(f'  board: could not parse {uuid} ({e}), using FR24 listings instead')
        return []
    nums = sorted({str(c).strip().upper() for r in (rows or []) for c in r
                   if re.fullmatch(r'[A-Z0-9]{2}\d{2,4}', str(c).strip().upper())})
    log(f'  board {day} ({sheet or "xlsx"}): {len(nums)} flight numbers')
    return [n for n in nums if n.startswith('UR')] or nums


def today_iso():
    return dt.date.today().isoformat()


def manifest_numbers(out_dir):
    """Flight numbers from our own earlier captures, i.e. from what FR24 reported.

    `capture_manifest.json` is what this script writes at the end of every run, so a night when the
    operator board is unreachable still knows which numbers are worth querying.
    """
    p = os.path.join(out_dir, 'capture_manifest.json')
    if not os.path.exists(p):
        return []
    try:
        d = json.load(open(p))
    except Exception:                                            # noqa: BLE001
        return []
    rows = d.get('flights') if isinstance(d, dict) else d
    if not isinstance(rows, list):
        rows = d.get('files') if isinstance(d, dict) else []
    nums = set()
    for r in rows or []:
        if isinstance(r, str):                                   # names like UR110-42691ba7.csv
            mt = re.match(r'([A-Z0-9]{2}\d{2,4})-', r)
            if mt:
                nums.add(mt.group(1))
            continue
        n = str((r or {}).get('flight') or (r or {}).get('number') or '').strip().upper()
        if n:
            nums.add(n)
    return sorted(nums)


def flight_numbers(path):
    """Distinct IATA flight numbers out of a month log or manifest.

    The log's `flight` column holds the radio callsign (`UGD209`), not the flight number, so
    the number is taken from the `source_file` prefix (`UR209-41e99651.csv`) where there is
    one — that is the name the build gave the track, so it cannot disagree with the archive —
    and a bare UGD/UGA callsign is folded to `UR` as the fallback. Hash-only filenames and
    non-UR operators contribute nothing, which is correct: their number is not ours to guess.
    """
    nums = set()
    with open(path, newline='', encoding='utf-8', errors='replace') as fh:
        for r in csv.DictReader(fh):
            for key in ('source_file', 'file'):
                m = re.match(r'^([A-Z0-9]{2}\d{2,4})-[0-9a-f]{6,8}\.csv$',
                             (r.get(key) or '').strip())
                if m:
                    nums.add(m.group(1).upper())
                    break
            else:
                cs = (r.get('flight') or r.get('callsign') or '').strip().upper()
                if re.fullmatch(r'UG[DAZ]\d{2,4}', cs):
                    nums.add('UR' + cs[3:])
    return sorted(nums)


def listings(num, limit, log, page=1, before=None):
    """Recent flights of one number, newest first, as flat records.

    `page` past 1 and `before` (a unix time: only flights that departed earlier) are the
    subscriber's history paging; asked anonymously FR24 answers with nothing useful, so
    main() only passes them when load_auth() found a key.
    """
    q = {'query': num, 'fetchBy': 'flight', 'mode': 'original', 'limit': limit, 'page': page}
    if before:
        q['filterBy'] = 'historic'
        q['timestamp'] = int(before)
    q.update(AUTH)
    q = urllib.parse.urlencode(q)
    j = get(f'{API}/flight/list.json?{q}', log=log)
    rows = []
    for it in ((j or {}).get('result', {}).get('response', {}) or {}).get('data') or []:
        ident = it.get('identification') or {}
        t = it.get('time') or {}
        real, sch = t.get('real') or {}, t.get('scheduled') or {}
        ap = it.get('airport') or {}
        dep = real.get('departure') or sch.get('departure')
        rows.append({
            'id': ident.get('id'), 'row': ident.get('row'),
            'number': ((ident.get('number') or {}).get('default') or num).upper(),
            'callsign': ident.get('callsign') or '',
            'status': (it.get('status') or {}).get('text') or '',
            'dep': dep, 'arr': real.get('arrival') or t.get('estimated', {}).get('arrival'),
            'origin': ((ap.get('origin') or {}).get('code') or {}).get('iata') or '',
            'dest': ((ap.get('destination') or {}).get('code') or {}).get('iata') or '',
        })
    return rows


def fixes(flight_id, log):
    """The map's trail for one flight, ascending in time. Empty list means 'too old', not 'no flight'."""
    j = get(f'{LIVE}/clickhandler/?version=1.5&flight={urllib.parse.quote(str(flight_id))}', log=log)
    r = (j or {}).get('result') if isinstance((j or {}).get('result'), dict) else j
    src = r or {}
    tr = src.get('track') or src.get('trail') or []
    out = []
    for p in tr:
        try:
            ts = int(p['ts'])
        except Exception:                                        # noqa: BLE001
            continue
        out.append({'ts': ts, 'lat': float(p['lat']), 'lon': float(p['lng']),
                    'alt': int(float(p.get('alt') or 0)), 'spd': int(float(p.get('spd') or 0)),
                    'hd': int(float(p.get('hd') or 0))})
    out.sort(key=lambda p: p['ts'])
    return out



def playback_fixes(flight_id, log):
    """The recorded track of one flight, from FR24's playback endpoint.

    The map's trail that fixes() reads is only kept for a few days; this answer is good for
    weeks, and each point carries a vertical rate and a squawk too. Points are returned in the
    same dicts fixes() returns, so the file written afterwards is the file our build already
    knows how to read. An empty list means FR24 has no recording of that flight, which is
    different from the flight not having flown - main() counts them apart.
    """
    q = {'flightId': str(flight_id)}
    q.update(AUTH)
    j = get('%s/flight-playback.json?%s' % (API, urllib.parse.urlencode(q)), log=log)
    f = ((((j or {}).get('result') or {}).get('response') or {}).get('data') or {}).get('flight') or {}
    out = []
    for p in f.get('track') or []:
        try:
            out.append({'ts': int(p['timestamp']),
                        'lat': float(p['latitude']), 'lon': float(p['longitude']),
                        'alt': int(float((p.get('altitude') or {}).get('feet') or 0)),
                        'spd': int(float((p.get('speed') or {}).get('kts') or 0)),
                        'hd': int(float(p.get('heading') or 0)),
                        'vs': int(float((p.get('verticalSpeed') or {}).get('fpm') or 0)),
                        'squawk': str(p.get('squawk') or '')})
        except Exception:                                         # noqa: BLE001
            continue
    out.sort(key=lambda x: x['ts'])
    return out


def write_csv(path, rec, pts, extra=False):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    hdr = HEADER + (EXTRA if extra else [])
    w.writerow(hdr)
    cs = rec['callsign'] or ''
    for p in pts:
        row = [p['ts'], dt.datetime.fromtimestamp(p['ts'], dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
               cs, f"{p['lat']:.6f},{p['lon']:.6f}", p['alt'], p['spd'], p['hd']]
        if extra:
            row += [p.get('vs', ''), p.get('squawk', '')]
        w.writerow(row)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(buf.getvalue())


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--flights', default='', help='comma list of flight numbers (default: read --from-log)')
    ap.add_argument('--from-log', default='auto',
                    help="'auto' unions the flight numbers from every UR*/flights.csv in the repository, "
                         "or one specific file. These are only the numbers to ASK FR24 about; every flight "
                         "written out is one FR24 itself reported, which is why this is not a rebuild from "
                         "a person's upload")
    ap.add_argument('--since', default='', help='first departure date, YYYY-MM-DD (default: 4 days ago)')
    ap.add_argument('--until', default='', help='last departure date, inclusive')
    ap.add_argument('--out', default='work/ci_capture', help='where to write the CSVs and the zip')
    ap.add_argument('--archive', default='fr24_publish/FR data.zip',
                    help='archive to skip already-held ids against ("" to disable)')
    ap.add_argument('--limit', type=int, default=30, help='listings fetched per flight number')
    ap.add_argument('--min-fixes', type=int, default=8, help='ignore trails thinner than this')
    ap.add_argument('--sleep', type=float, default=2.5, help='seconds between requests (a 429 '
                        'arrives below about two); 429 and 5xx are retried with backoff')
    ap.add_argument('--cap', type=int, default=400, help='stop after this many captures')
    ap.add_argument('--zip-name', default='FR data.zip')
    ap.add_argument('--seen-before', default='', help='an earlier out dir holding capture_manifest.json, '
                        'to reuse the flight numbers FR24 already told us about')
    ap.add_argument('--source', default='board', choices=('board', 'log'),
                    help='where the day\'s flight numbers come from: the operator board page (default) '
                         'or --from-log')
    ap.add_argument('--trail', default='live', choices=('live', 'playback', 'both'),
                    help="where the points come from: 'live' is the map's trail (only kept a few "
                         "days), 'playback' is FR24's recording of the flight (good for weeks, and "
                         "each point has a vertical rate and a squawk), 'both' takes the live trail "
                         "and falls back to playback when it comes back thin - which is what makes "
                         "an older date worth asking about at all")
    ap.add_argument('--pages', type=int, default=1,
                    help='pages of listings to walk per flight number (subscriber paging only; '
                         'page past 1 anonymously returns nothing, so this is ignored without --auth)')
    ap.add_argument('--auth', default='auto', choices=('auto', 'off'),
                    help="'auto' reads a subscription key from the environment or ~/.config/fr24/fr24.conf "
                         "(nothing is written back); 'off' never looks, not even for the file")
    ap.add_argument('--extra-columns', action='store_true',
                    help='append VerticalSpeed and Squawk to each fix. Off by default because the ten '
                         'scripts that read these files were written for the seven columns above')
    ap.add_argument('--dry-run', action='store_true', help='list what would be fetched, write nothing')
    a = ap.parse_args()
    log = lambda m: (print(m), sys.stdout.flush())

    now = dt.datetime.now(dt.timezone.utc)
    since = (dt.date.fromisoformat(a.since) if a.since else (now - dt.timedelta(days=4)).date())
    until = dt.date.fromisoformat(a.until) if a.until else now.date()
    keyed = load_auth(log, want=(a.auth == 'auto'))
    pages = a.pages if keyed else 1
    if a.pages > 1 and not keyed:
        log('  --pages %d ignored: paging backwards is a subscriber answer and we have no key' % a.pages)

    # Which flights to look for, in order of preference. The operator's board page first, because it
    # says what UR meant to fly that day; then the numbers FR24 itself reported on an earlier night;
    # and only on an explicit --source log do we read the month log, which is a person's upload.
    nums, src = [], ''
    if a.flights.strip():
        nums = [n.strip().upper() for n in a.flights.split(',') if n.strip()]
        src = 'called with --flights'
    if not nums and a.source == 'board':
        nums = flights_from_board(until.isoformat(), log)
        src = 'the UR board page at fta.ugandairlines.com'
    if not nums and (a.seen_before or a.out):
        got = manifest_numbers(a.seen_before or a.out)
        if got:
            nums = got
            src = f'what FR24 reported on the last run into {a.seen_before or a.out}'
    if not nums and a.source == 'log':
        if a.from_log == 'auto':
            root = os.environ.get('FR24_PUBLISH') or os.path.join(ROOT, 'fr24_publish')
            files = sorted(glob.glob(os.path.join(root, 'UR*', 'flights.csv')))
        else:
            files = [a.from_log] if os.path.exists(a.from_log) else []
        for fp in files:
            nums = sorted(set(nums) | set(flight_numbers(fp)))
        src = ('the flight numbers recorded in %d month log(s) here; the flights themselves come from '
               'FR24, which is the only thing this writes' % len(files))
    if not nums:
        log('nothing to fetch: the board page gave no flight numbers for '
            f'{until.isoformat()} and no earlier capture is recorded at {a.out}.')
        log('This is not a failure of the archive — it means the only list we could have used was a '
            "person's upload, and that is deliberately no longer the source. Pass --flights UR209,UR208 "
            'to name the day explicitly, or re-run when the board answers.')
        return 4

    have = known_ids(a.archive)
    log(f'fetch: {len(nums)} flight numbers · departures {since} to {until} · '
        f'{len(have):,} ids already in {a.archive or "(no archive)"}')

    os.makedirs(a.out, exist_ok=True)
    files, rec_rows = [], []
    seen = new = empty = skipped = out_of_window = 0
    for num in nums:
        raw = []
        for page in range(1, pages + 1):
            got = listings(num, a.limit, log, page=page,
                           before=(until + dt.timedelta(days=1)) if keyed else None)
            raw += got
            if len(got) < a.limit:
                break
        STATS['rows'] += len(raw)          # rows the API named, before any date filter of ours
        recs = [r for r in raw if r['id']]
        for r in recs:
            seen += 1
            if not r['dep']:
                skipped += 1                                    # scheduled, not flown yet
                continue
            d = dt.datetime.fromtimestamp(r['dep'], dt.timezone.utc).date()
            if not (since <= d <= until):
                out_of_window += 1
                continue
            if r['id'].lower() in have:
                skipped += 1
                continue
            time.sleep(a.sleep)
            pts, how = [], 'playback'
            if a.trail in ('live', 'both'):
                pts, how = fixes(r['id'], log), 'live trail'
            if len(pts) < a.min_fixes and a.trail in ('playback', 'both'):
                pb = playback_fixes(r['id'], log)
                if len(pb) > len(pts):
                    pts, how = pb, 'playback'
            if len(pts) < a.min_fixes:
                empty += 1
                log(f'  {num} {d} {r["origin"]}->{r["dest"]:4} id={r["id"]}  '
                    f'{"no recording kept by FR24" if not pts else "only %d fixes" % len(pts)}')
                continue
            name = f"{r['number']}-{r['id']}.csv"
            p = os.path.join(a.out, name)
            if a.dry_run:
                log(f'  would write {name}: {len(pts)} fixes ({how}) '
                    f'{time.strftime("%m-%d %H:%M", time.gmtime(pts[0]["ts"]))} -> '
                    f'{time.strftime("%m-%d %H:%M", time.gmtime(pts[-1]["ts"]))}')
            else:
                write_csv(p, r, pts, extra=a.extra_columns)
                files.append(p)
                log(f'  wrote {name}: {len(pts)} fixes ({how}), {r["status"]}')
            new += 1
            rec_rows.append({**r, 'dep_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(r['dep'])),
                             'fixes': len(pts),
                             'first_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(pts[0]['ts'])),
                             'last_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(pts[-1]['ts']))})
            if new >= a.cap:
                log(f'  --cap {a.cap} reached, stopping')
                break
        time.sleep(a.sleep)
    if a.dry_run:
        log(f'\ndry run: {new} flight(s) would be fetched, {empty} too old, '
            f'{skipped} already held, {out_of_window} outside the window')
        return 0

    zpath = os.path.join(a.out, a.zip_name)
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(p, os.path.basename(p))
    with open(os.path.join(a.out, 'capture_manifest.json'), 'w') as fh:
        json.dump({'fetched_utc': now.strftime('%Y-%m-%dT%H:%M:%SZ'),
                   # Provenance, in the file that travels with the capture, because a capture can be
                   # built on one machine and read on another and nobody should have to remember which.
                   'numbers_from': src, 'trail': a.trail, 'subscriber_key': bool(keyed),
                   'since': str(since),
                   'until': str(until), 'listings_seen': seen, 'captured': new,
                   'too_old_or_thin': empty, 'already_held_or_scheduled': skipped,
                   'files': [os.path.basename(p) for p in sorted(files)], 'flights': rec_rows},
                  fh, indent=1)
    log(f'\ncaptured {new} of {seen} listing(s): {empty} too old or thin, '
        f'{skipped} already held or not flown')
    if new:
        log(f'zip: {zpath} ({os.path.getsize(zpath):,} B, {len(files)} files)')
        log('next: python3 fr24_update.py --zip "%s" --month auto' % zpath)
    else:
        log('nothing new to write — the zip was not rebuilt')
    # exit codes the workflow acts on: 0 something captured or nothing new to do,
    # 3 the board/listings answered but every trail had expired, 4 nothing answered at all
    # (blocked or offline), which is a run failure and not a quiet rebuild from the archive.
    if not STATS['answered']:
        return 4            # not one reply: no route, TLS, or a hard 403 at the edge
    if not new and not STATS['rows']:
        return 5            # it replied, and named no flight at all: a polite block, not a quiet day
    return 0 if new else 3


if __name__ == '__main__':
    sys.exit(main())
